// Создание объекта с данными автомобилей
const cars = {
  "Tesla Model S": {
    name: "Tesla Model S",
    wheels: 4,
    doors: 4,
    isStarted: true,
    hp: 1020,
  },
  "BMW M3": {
    name: "BMW M3",
    wheels: 4,
    doors: 4,
    isStarted: false,
    hp: 473,
  },
  "Audi A4": {
    name: "Audi A4",
    wheels: 4,
    doors: 4,
    isStarted: true,
    hp: 250,
  },
};

// Функция для вывода названий автомобилей
function listCarNames() {
  for (let car in cars) {
    console.log(car);
  }
}

// Пример использования
listCarNames();
